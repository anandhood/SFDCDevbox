({
	getLifeInsurance : function(component) {
        console.log('Inside getLifeInsurance helper');
		var acctId = component.get("v.recordId");
        console.log('Record id: ' + acctId);
        var action = component.get("c.getLifeInsurancePolicies");
        action.setParams({
            "accountId" : acctId
        });
        action.setCallback(this, function(response){
        	var state = response.getState();
            if(state === 'SUCCESS'){
            	component.set("v.ProductSummaryRecordList", response.getReturnValue());
            }            
        });
        $A.enqueueAction(action);
	}
})