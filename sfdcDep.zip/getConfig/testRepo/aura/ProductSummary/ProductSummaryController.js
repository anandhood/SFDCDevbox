({
	doInit : function(component, event, helper) {
        console.log('in doInit');
        helper.getLifeInsurance(component);
	},
})